# Defect Predictor (Starter Repo)

A Python project to predict defect-prone files/modules using static and process metrics.

## Quickstart

```bash
# 1) Create venv and install deps
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate
pip install -r requirements.txt

# 2) (Option A) Mine a local repo for features + labels
python -m src.extract.static_metrics --repo ./target_repo --out data/static.csv
python -m src.extract.process_metrics --repo ./target_repo --out data/process.csv
python -m src.label.labeler --repo ./target_repo --out data/labels.csv

# 3) Train & evaluate
python -m src.models.train --features data/static.csv data/process.csv --labels data/labels.csv --out artifacts

# 4) Predict risks & generate report
python -m src.models.predict --model artifacts/rf.pkl --features data/static.csv data/process.csv --out reports/risk.csv
python -m src.report.make_report --risk reports/risk.csv --out reports/report.html

# 5) Launch dashboard
python -m src.report.app
```
