import argparse
import pandas as pd
import joblib

EXCLUDE = {"file", "defect_prone", "last_ts"}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="Path to a .pkl model (e.g., artifacts/rf.pkl)")
    ap.add_argument("--features", nargs="+", required=True, help="CSV(s) with features to merge on 'file'")
    ap.add_argument("--out", required=True, help="Output CSV path with risk scores")
    args = ap.parse_args()

    df = None
    for f in args.features:
        part = pd.read_csv(f)
        df = part if df is None else df.merge(part, on="file", how="outer")

    feats = [c for c in df.columns if c not in EXCLUDE]
    X = df[feats].fillna(0)

    model = joblib.load(args.model)
    df["risk"] = model.predict_proba(X)[:, 1]
    df.sort_values("risk", ascending=False).to_csv(args.out, index=False)
    print(f"[predict] Wrote: {args.out}")

if __name__ == "__main__":
    main()
