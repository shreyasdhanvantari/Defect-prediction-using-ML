import argparse
import pathlib
import pandas as pd
from radon.complexity import cc_visit
from radon.metrics import mi_visit, mi_parameters
import pycodestyle

def list_py_files(repo_path: str):
    return [str(p) for p in pathlib.Path(repo_path).rglob('*.py')]

def count_pep8_violations(path: str) -> int:
    style = pycodestyle.StyleGuide(ignore=[], quiet=True)
    report = style.check_files([path])
    return report.total_errors

def file_metrics(path: str) -> dict:
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            src = f.read()
        loc = src.count('\n') + 1
        cc_nodes = cc_visit(src)
        avg_cc = sum(n.complexity for n in cc_nodes) / max(1, len(cc_nodes))
        mi = mi_visit(src, **mi_parameters)
        pep8 = count_pep8_violations(path)
        return dict(file=path, loc=loc, avg_cc=avg_cc, mi=mi, pep8=pep8)
    except Exception:
        return dict(file=path, loc=None, avg_cc=None, mi=None, pep8=None)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True, help="Path to a local repository with .py files")
    ap.add_argument("--out", required=True, help="Output CSV path")
    args = ap.parse_args()

    files = list_py_files(args.repo)
    rows = [file_metrics(p) for p in files]
    pd.DataFrame(rows).to_csv(args.out, index=False)
    print(f"[static_metrics] Wrote: {args.out} ({len(rows)} files)")

if __name__ == "__main__":
    main()
