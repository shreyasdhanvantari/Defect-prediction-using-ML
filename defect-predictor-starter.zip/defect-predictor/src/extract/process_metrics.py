import argparse
import pandas as pd
from pydriller import Repository
from datetime import datetime

def mine(repo_path: str) -> pd.DataFrame:
    rows = {}
    for commit in Repository(repo_path).traverse_commits():
        for m in commit.modified_files:
            # Use new_path if present else old_path
            fpath = m.new_path or m.old_path
            if not fpath or not fpath.endswith(".py"):
                continue
            r = rows.get(fpath, dict(file=fpath, commits=0, added=0, removed=0, authors=set(), last_ts=None))
            r["commits"] += 1
            r["added"] += (m.added or 0)
            r["removed"] += (m.removed or 0)
            r["authors"].add((commit.author.name or "") + "<" + (commit.author.email or "") + ">")
            r["last_ts"] = commit.author_date  # datetime
            rows[fpath] = r

    out = []
    for v in rows.values():
        out.append({
            "file": v["file"],
            "commits": v["commits"],
            "churn": v["added"] + v["removed"],
            "authors": len(v["authors"]),
            "last_ts": v["last_ts"].isoformat() if isinstance(v["last_ts"], datetime) else None
        })
    return pd.DataFrame(out)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True, help="Path to a local git repository")
    ap.add_argument("--out", required=True, help="Output CSV path")
    args = ap.parse_args()

    df = mine(args.repo)
    df.to_csv(args.out, index=False)
    print(f"[process_metrics] Wrote: {args.out} ({len(df)} rows)")

if __name__ == "__main__":
    main()
