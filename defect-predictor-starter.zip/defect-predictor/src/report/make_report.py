import argparse
import pandas as pd
import matplotlib.pyplot as plt

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--risk", required=True, help="CSV with 'file' and 'risk'")
    ap.add_argument("--out", required=True, help="Output HTML path")
    args = ap.parse_args()

    df = pd.read_csv(args.risk)
    # Simple plot: top 20 risky files
    top = df.sort_values("risk", ascending=False).head(20)
    plt.figure()
    plt.barh(top["file"].astype(str), top["risk"].astype(float))
    plt.gca().invert_yaxis()
    plt.title("Top 20 Risky Files (higher = riskier)")
    plt.tight_layout()
    plt.savefig(args.out.replace('.html', '_top20.png'))

    # Minimal HTML
    html = [
        "<html><head><meta charset='utf-8'><title>Defect Risk Report</title></head><body>",
        "<h1>Defect Risk Report</h1>",
        f"<img src='{args.out.replace('.html', '_top20.png')}' alt='Top 20 Risky Files'>",
        df.sort_values("risk", ascending=False).head(100).to_html(index=False),
        "</body></html>"
    ]
    with open(args.out, "w", encoding="utf-8") as f:
        f.write("\n".join(html))
    print(f"[make_report] Wrote: {args.out}")

if __name__ == "__main__":
    main()
